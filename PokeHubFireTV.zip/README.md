# Poké Hub — Fire TV

App Android nativo em Java para Fire TV / Android TV, controlado pelo controle remoto.

- Pokédex pesquisável (dados locais de exemplo)
- Batalhas por turnos
- Pokémon companheiro
- Coleção e conquistas (salvas em `SharedPreferences`)
- Mapa de regiões
- Efeitos sonoros locais
- Atalhos para apps instalados

## Gerar o APK pelo GitHub

1. Abra **Actions** → **Build PokeHub Fire TV APK** → **Run workflow** (ou faça push na `main`).
2. Ao terminar, baixe o artefato `PokeHubFireTV-debug-apk`.
3. Extraia e instale o `app-debug.apk` na Fire TV.

APK de depuração, sem assinatura de distribuição. Requer Java 17 e Android SDK 35 (já configurados no workflow).
