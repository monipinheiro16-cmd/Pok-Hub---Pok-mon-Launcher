package br.com.pokehub.firetv;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.net.Uri;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.text.*;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    final int BG=Color.rgb(13,22,48), PANEL=Color.rgb(26,43,79), BLUE=Color.rgb(46,105,190), YELLOW=Color.rgb(255,205,60), WHITE=Color.WHITE, MUTED=Color.rgb(190,207,235);
    LinearLayout root, content, nav;
    ToneGenerator tones;
    String page="Início", companion="Pikachu";
    int playerHp=100, enemyHp=100, wins=0, battles=0;
    boolean soundOn=true;
    Set<String> caught=new HashSet<>(), achievements=new HashSet<>();
    android.content.SharedPreferences prefs;
    final String[][] pokemon={
        {"Pikachu","Elétrico","⚡","Rápido e cheio de energia."},
        {"Bulbasaur","Planta / Veneno","🌱","Carrega uma semente nas costas."},
        {"Charmander","Fogo","🔥","A chama da cauda reflete sua energia."},
        {"Squirtle","Água","💧","Usa jatos d'água para se defender."},
        {"Eevee","Normal","🦊","Tem potencial para várias evoluções."},
        {"Jigglypuff","Normal / Fada","🎤","Sua canção pode fazer os outros dormir."},
        {"Meowth","Normal","🐱","Adora moedas brilhantes."},
        {"Psyduck","Água","🦆","Às vezes libera poderes psíquicos."},
        {"Snorlax","Normal","💤","Adora dormir e comer."},
        {"Gengar","Fantasma / Veneno","👻","Adora pregar peças nas sombras."},
        {"Lucario","Lutador / Aço","🥋","Percebe a aura ao seu redor."},
        {"Mew","Psíquico","✨","Um Pokémon misterioso e raro."},
        {"Dragonite","Dragão / Voador","🐉","Gentil e capaz de voar muito rápido."},
        {"Arcanine","Fogo","🐕","Conhecido por sua velocidade e coragem."},
        {"Piplup","Água","🐧","Orgulhoso e determinado."},
        {"Togepi","Fada","🥚","Traz alegria para quem o encontra."},
        {"Gardevoir","Psíquico / Fada","🔮","Protege intensamente seu treinador."},
        {"Greninja","Água / Sombrio","🐸","Move-se com agilidade impressionante."},
        {"Rowlet","Planta / Voador","🦉","Um pequeno arqueiro silencioso."},
        {"Mimikyu","Fantasma / Fada","👻","Esconde sua aparência sob um disfarce."}
    };

    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY); prefs=getSharedPreferences("pokehub",MODE_PRIVATE); load(); try{tones=new ToneGenerator(AudioManager.STREAM_MUSIC,65);}catch(Exception ignored){} showHome();}
    void load(){caught.addAll(prefs.getStringSet("caught",new HashSet<String>())); achievements.addAll(prefs.getStringSet("achievements",new HashSet<String>())); wins=prefs.getInt("wins",0); battles=prefs.getInt("battles",0); companion=prefs.getString("companion","Pikachu");}
    void save(){prefs.edit().putStringSet("caught",new HashSet<>(caught)).putStringSet("achievements",new HashSet<>(achievements)).putInt("wins",wins).putInt("battles",battles).putString("companion",companion).apply();}
    GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;}
    TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    void pad(View v,int n){v.setPadding(n,n,n,n);}
    LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    TextView button(String label,Runnable action){
        TextView b=text(label,19,WHITE);b.setGravity(Gravity.CENTER);b.setFocusable(true);b.setClickable(true);b.setPadding(18,12,18,12);b.setBackground(shape(BLUE,18));
        b.setOnFocusChangeListener((v,has)->b.setBackground(shape(has?Color.rgb(232,151,39):BLUE,18)));
        b.setOnClickListener(v->{if(soundOn&&tones!=null)tones.startTone(ToneGenerator.TONE_PROP_ACK,80);action.run();});
        LinearLayout.LayoutParams p=lp(-2,-2);p.setMargins(6,6,6,6);b.setLayoutParams(p);return b;
    }
    void shell(String title,String subtitle){
        root=column();root.setBackgroundColor(BG);setContentView(root);
        LinearLayout header=row();header.setPadding(28,12,28,8);
        TextView logo=text("🔴 POKÉ HUB",25,YELLOW);logo.setTypeface(null,Typeface.BOLD);header.addView(logo,new LinearLayout.LayoutParams(0,58,1));
        TextView stat=text("🏆 "+wins+" vitórias   ·   🎒 "+caught.size()+" capturados",15,MUTED);header.addView(stat);
        root.addView(header,lp(-1,-2));
        TextView h=text(title,29,WHITE);h.setTypeface(null,Typeface.BOLD);h.setPadding(30,4,20,0);root.addView(h,lp(-1,45));
        TextView sub=text(subtitle,15,MUTED);sub.setPadding(30,0,20,8);root.addView(sub,lp(-1,30));
        ScrollView scroll=new ScrollView(this);content=column();content.setPadding(24,8,24,24);scroll.setFillViewport(true);scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        TextView footer=text("◀ Voltar   •   Setas para navegar   •   OK para selecionar",13,MUTED);footer.setGravity(Gravity.CENTER);footer.setPadding(10,8,10,8);root.addView(footer,lp(-1,34));
    }
    void card(String title,String body,String emoji,Runnable action){
        LinearLayout c=column();c.setPadding(18,12,18,12);c.setBackground(shape(PANEL,18));c.setFocusable(true);c.setClickable(true);
        TextView a=text(emoji+"  "+title,21,YELLOW);a.setTypeface(null,Typeface.BOLD);c.addView(a,lp(-1,38));TextView b=text(body,15,MUTED);c.addView(b,lp(-1,-2));
        c.setOnFocusChangeListener((v,f)->c.setBackground(shape(f?Color.rgb(49,73,120):PANEL,18)));c.setOnClickListener(v->{if(soundOn&&tones!=null)tones.startTone(ToneGenerator.TONE_PROP_ACK,70);action.run();});
        LinearLayout.LayoutParams p=lp(-1,-2);p.setMargins(5,5,5,5);content.addView(c,p);
    }
    void showHome(){
        page="Início";shell("Uma aventura começa aqui!","Seu centro Pokémon para televisão — use o controle remoto.");
        LinearLayout hero=column();hero.setPadding(22,18,22,18);hero.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{Color.rgb(160,40,55),Color.rgb(35,78,157)}));((GradientDrawable)hero.getBackground()).setCornerRadius(24);
        TextView big=text("⚡ "+companion+" ⚡",36,WHITE);big.setTypeface(null,Typeface.BOLD);hero.addView(big,lp(-1,62));
        hero.addView(text("Seu companheiro está pronto para a próxima aventura.",18,WHITE),lp(-1,38));
        LinearLayout.LayoutParams hp=lp(-1,-2);hp.setMargins(4,5,4,12);content.addView(hero,hp);
        LinearLayout r=row();r.addView(button("📘 Pokédex",()->showPokedex()),new LinearLayout.LayoutParams(0,-2,1));r.addView(button("⚔ Batalha",()->showBattle()),new LinearLayout.LayoutParams(0,-2,1));content.addView(r);
        LinearLayout r2=row();r2.addView(button("🗺 Regiões",()->showMap()),new LinearLayout.LayoutParams(0,-2,1));r2.addView(button("🎒 Coleção",()->showCollection()),new LinearLayout.LayoutParams(0,-2,1));content.addView(r2);
        card("Companheiro Pokémon","Troque seu parceiro e acompanhe sua jornada.","💛",()->showCompanion());
        card("Aplicativos da Fire TV","Veja os aplicativos instalados que o Android permitir abrir.","📺",()->showApps());
        card("Som e música","Ative ou desative os efeitos sonoros da interface.","🎵",()->showAudio());
        content.post(()->{View v=content.getChildAt(1);if(v!=null)v.requestFocus();});
    }
    void showPokedex(){
        page="Pokédex";shell("Pokédex","Pesquise por nome, tipo ou descrição. As fichas funcionam sem internet.");
        EditText search=new EditText(this);search.setSingleLine(true);search.setTextColor(WHITE);search.setHintTextColor(MUTED);search.setHint("Pesquisar Pokémon…");search.setTextSize(18);search.setPadding(18,8,18,8);search.setBackground(shape(PANEL,14));content.addView(search,lp(-1,55));
        LinearLayout results=column();content.addView(results);
        Runnable refresh=()->{results.removeAllViews();String q=search.getText().toString().toLowerCase(Locale.ROOT);for(String[] p:pokemon){if((p[0]+" "+p[1]+" "+p[3]).toLowerCase(Locale.ROOT).contains(q)){cardIn(results,p[2]+"  "+p[0],p[1]+"  •  "+p[3],caught.contains(p[0])?"✅ Capturado":"📖 Ver ficha",()->showPokemon(p));}}};
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){refresh.run();}public void afterTextChanged(Editable e){}});refresh.run();search.setNextFocusDownId(View.generateViewId());search.requestFocus();
    }
    void cardIn(LinearLayout parent,String title,String body,String actionLabel,Runnable action){
        LinearLayout c=column();c.setPadding(15,9,15,9);c.setBackground(shape(PANEL,14));c.setFocusable(true);c.setClickable(true);
        TextView t=text(title,19,YELLOW);c.addView(t,lp(-1,32));c.addView(text(body,14,MUTED),lp(-1,-2));c.addView(text(actionLabel,13,WHITE),lp(-1,28));c.setOnFocusChangeListener((v,f)->c.setBackground(shape(f?Color.rgb(49,73,120):PANEL,14)));c.setOnClickListener(v->action.run());LinearLayout.LayoutParams p=lp(-1,-2);p.setMargins(2,4,2,4);parent.addView(c,p);
    }
    void showPokemon(String[] p){
        shell(p[2]+" "+p[0],"Ficha da Pokédex");
        card("Tipo",p[1],"🔹",()->{});card("Sobre",p[3],"📚",()->{});
        card("Registro",caught.contains(p[0])?"Este Pokémon já faz parte da sua coleção.":"Adicione à sua coleção local.","🎒",()->{caught.add(p[0]);if(caught.size()>=5)achievements.add("Colecionador iniciante");save();showPokemon(p);});
        content.addView(button("⭐ Escolher como companheiro",()->{companion=p[0];save();showCompanion();}));
        content.addView(button("← Voltar à Pokédex",()->showPokedex()));
    }
    void showCompanion(){
        page="Companheiro";shell("Seu companheiro","Escolha um Pokémon para aparecer na tela inicial.");
        TextView hero=text("✨  "+companion+"  ✨",40,YELLOW);hero.setGravity(Gravity.CENTER);hero.setBackground(shape(PANEL,22));content.addView(hero,lp(-1,120));
        content.addView(text("Toque OK em um Pokémon para torná-lo seu parceiro.",17,MUTED));
        for(String[] p:pokemon)content.addView(button(p[2]+"  "+p[0]+(companion.equals(p[0])?"  ✓":""),()->{companion=p[0];caught.add(p[0]);save();showCompanion();}));
        content.addView(button("← Início",()->showHome()));
    }
    void showBattle(){
        page="Batalha";shell("Arena Pokémon","Batalha por turnos. Ataques e resultados são calculados no aplicativo.");
        content.addView(text("Seu Pokémon: "+companion,25,YELLOW));TextView php=text("❤️ Seus PS: "+playerHp+"/100",20,WHITE);content.addView(php,lp(-1,42));
        TextView ehp=text("👾 PS do adversário: "+enemyHp+"/100",20,WHITE);content.addView(ehp,lp(-1,42));
        content.addView(button("⚡ Ataque rápido (18–28)",()->attack(18,28,php,ehp)));
        content.addView(button("💥 Ataque especial (12–38)",()->attack(12,38,php,ehp)));
        content.addView(button("🧪 Recuperar 20 PS",()->{playerHp=Math.min(100,playerHp+20);php.setText("❤️ Seus PS: "+playerHp+"/100");}));
        content.addView(button("🔄 Nova batalha",()->{playerHp=100;enemyHp=100;showBattle();}));
        content.addView(button("← Início",()->showHome()));
    }
    void attack(int min,int max,TextView php,TextView ehp){
        if(playerHp<=0||enemyHp<=0){toast("A batalha terminou. Inicie uma nova batalha.");return;}
        enemyHp=Math.max(0,enemyHp-(min+new Random().nextInt(max-min+1)));
        if(enemyHp>0)playerHp=Math.max(0,playerHp-(8+new Random().nextInt(16)));
        php.setText("❤️ Seus PS: "+playerHp+"/100");ehp.setText("👾 PS do adversário: "+enemyHp+"/100");
        if(enemyHp==0){wins++;battles++;caught.add("Pikachu");achievements.add("Primeira vitória");if(wins>=5)achievements.add("Mestre da arena");save();toast("Vitória! Você ganhou uma conquista.");}
        else if(playerHp==0){battles++;save();toast("Você perdeu esta batalha. Tente novamente!");}
    }
    void showCollection(){
        page="Coleção";shell("Coleção e conquistas","Seu progresso fica salvo neste dispositivo.");
        card("Pokémon capturados",caught.isEmpty()?"Ainda não capturou nenhum. Abra a Pokédex para adicionar Pokémon.":String.join("  •  ",caught),"🎒",()->showPokedex());
        card("Vitórias na arena",String.valueOf(wins)+" vitória(s) em "+battles+" batalha(s).","🏆",()->{});
        card("Conquistas",achievements.isEmpty()?"Explore a Pokédex e vença batalhas para desbloquear conquistas.":String.join("\n• ",achievements),"🌟",()->{});
        content.addView(button("← Início",()->showHome()));
    }
    void showMap(){
        page="Mapa";shell("Mapa de regiões","Escolha uma região para revelar um ponto de exploração.");
        String[][] regions={{"Kanto","Pallet Town, Viridian e Floresta de Viridian"},{"Johto","New Bark, Violet e Floresta Ilex"},{"Hoenn","Littleroot, Rustboro e região costeira"},{"Sinnoh","Twinleaf, Jubilife e montanhas"},{"Unova","Nuvema, Castelia e rotas urbanas"},{"Kalos","Vaniville, Lumiose e trilhas"},{"Alola","Ilha Melemele, praias e vilas"},{"Paldea","Mesagoza, planícies e trilhas"}};
        for(String[] r:regions)card(r[0],r[1],"🗺",()->{achievements.add("Explorador: "+r[0]);save();new AlertDialog.Builder(this).setTitle("Região "+r[0]).setMessage("Você explorou "+r[0]+"!\n\n"+r[1]+"\n\nConquista registrada no seu perfil.").setPositiveButton("Continuar",(d,w)->showMap()).show();});
        content.addView(button("← Início",()->showHome()));
    }
    void showAudio(){
        page="Som";shell("Som e música","Controle de áudio local. Não inclui músicas protegidas.");
        content.addView(button(soundOn?"🔊 Efeitos: ligados":"🔇 Efeitos: desligados",()->{soundOn=!soundOn;showAudio();}));
        content.addView(text("Os efeitos são tons simples gerados pelo dispositivo. Música ambiente poderá ser adicionada depois com arquivos licenciados ou próprios.",17,MUTED));
        content.addView(button("🔔 Testar efeito",()->{if(tones!=null)tones.startTone(ToneGenerator.TONE_PROP_BEEP,180);}));
        content.addView(button("← Início",()->showHome()));
    }
    void showApps(){
        page="Aplicativos";shell("Aplicativos da Fire TV","A lista depende do que o sistema expõe. Alguns apps podem bloquear abertura externa.");
        PackageManager pm=getPackageManager();Intent query=new Intent(Intent.ACTION_MAIN,null);query.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
        List<android.content.pm.ResolveInfo> list=pm.queryIntentActivities(query,0);
        if(list==null||list.isEmpty()){query.removeCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);query.addCategory(Intent.CATEGORY_LAUNCHER);list=pm.queryIntentActivities(query,0);}
        final List<android.content.pm.ResolveInfo> apps=list;
        if(apps!=null){Collections.sort(apps,(a,b)->String.valueOf(a.loadLabel(pm)).compareToIgnoreCase(String.valueOf(b.loadLabel(pm))));int count=0;for(android.content.pm.ResolveInfo ri:apps){String label=String.valueOf(ri.loadLabel(pm));if(label.equals("Poké Hub"))continue;final String pkg=ri.activityInfo.packageName;content.addView(button("📺 "+label,()->{try{Intent launch=pm.getLaunchIntentForPackage(pkg);if(launch!=null)startActivity(launch);else toast("Este aplicativo não oferece atalho de abertura.");}catch(Exception e){toast("Não foi possível abrir este aplicativo.");}}));count++;if(count>=40)break;}}
        if(content.getChildCount()==0)content.addView(text("Nenhum aplicativo compatível foi listado. Você ainda pode abrir aplicativos pelo menu normal da Fire TV.",17,MUTED));
        content.addView(button("← Início",()->showHome()));
    }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override public boolean onKeyDown(int keyCode,KeyEvent event){
        if(keyCode==KeyEvent.KEYCODE_BACK){if(!page.equals("Início"))showHome();else new AlertDialog.Builder(this).setTitle("Sair do Poké Hub?").setMessage("Você pode voltar quando quiser pela lista de aplicativos.").setNegativeButton("Continuar",(d,w)->{}).setPositiveButton("Sair",(d,w)->finish()).show();return true;}
        return super.onKeyDown(keyCode,event);
    }
    @Override protected void onDestroy(){if(tones!=null)tones.release();super.onDestroy();}
}
